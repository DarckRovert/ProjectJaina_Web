-- ================================================================
-- SYSTEM HOTFIX: FrameXML / ChatFrame CHANNEL_NOTICE Nil Guard
-- Protege contra crash en ChatFrame.lua:2802 si el servidor envía notices no definidas en GlobalStrings
-- ================================================================
if not _G.CHAT_NOT_IN_LFG_NOTICE then
    _G.CHAT_NOT_IN_LFG_NOTICE = "|Hchannel:%d|h[%s]|h Debes unirte a la cola de Buscar grupo para poder participar en este canal."
end
if not _G.CHAT_NOT_IN_LFG_NOTICE_BN then
    _G.CHAT_NOT_IN_LFG_NOTICE_BN = "|Hchannel:CHANNEL:%d|h[%s]|h Debes unirte a la cola de Buscar grupo para poder participar en este canal."
end

local _Orig_ChatFrame_MessageEventHandler = _G.ChatFrame_MessageEventHandler
if _Orig_ChatFrame_MessageEventHandler then
    _G.ChatFrame_MessageEventHandler = function(self, event, ...)
        if event == "CHAT_MSG_CHANNEL_NOTICE" or event == "CHAT_MSG_CHANNEL_NOTICE_USER" then
            local noticeType = ...
            if noticeType then
                local bnKey = "CHAT_" .. tostring(noticeType) .. "_NOTICE_BN"
                local stdKey = "CHAT_" .. tostring(noticeType) .. "_NOTICE"
                if not _G[bnKey] and not _G[stdKey] then
                    _G[stdKey] = "|Hchannel:%d|h[%s]|h [" .. tostring(noticeType) .. "]"
                end
            end
        end
        return _Orig_ChatFrame_MessageEventHandler(self, event, ...)
    end
end

local DF = LibStub('AceAddon-3.0'):GetAddon('cDF')
local mName = 'Chat'
local Module = DF:NewModule(mName, 'AceConsole-3.0')

local db, getOptions

local defaults = {
    profile = {
        scale = 1,
        x = 42,
        y = 35,
        sizeX = 460,
        sizeY = 207
    }
}
local function getDefaultStr(key)
    return ' (Default: ' .. tostring(defaults.profile[key]) .. ')'
end

local function setDefaultValues()
    for k, v in pairs(defaults.profile) do
        Module.db.profile[k] = v
    end
    Module.ApplySettings()
end

-- db[info[#info] = VALUE
local function getOption(info)
    return db[info[#info]]
end

local function setOption(info, value)
    local key = info[#info]
    Module.db.profile[key] = value
    db = Module.db.profile
    Module.ApplySettings()
end

local options = {
    type = 'group',
    name = 'cDF - ' .. mName,
    get = getOption,
    set = setOption,
    args = {
        toggle = {
            type = 'toggle',
            name = 'Enable',
            get = function()
                return DF:GetModuleEnabled(mName)
            end,
            set = function(info, v)
                DF:SetModuleEnabled(mName, v)
            end,
            order = 1
        },
        reload = {
            type = 'execute',
            name = '/reload',
            desc = 'reloads UI',
            func = function()
                ReloadUI()
            end,
            order = 1.1
        },
        defaults = {
            type = 'execute',
            name = 'Defaults',
            desc = 'Sets Config to default values',
            func = setDefaultValues,
            order = 1.1
        },
        config = {
            type = 'header',
            name = 'Config - Chat',
            order = 100
        },
        scale = {
            type = 'range',
            name = 'Scale',
            desc = '' .. getDefaultStr('scale'),
            min = 0.2,
            max = 1.5,
            bigStep = 0.025,
            order = 101,
            disabled = true
        },
        x = {
            type = 'range',
            name = 'X',
            desc = 'X relative to BOTTOM LEFT' .. getDefaultStr('x'),
            min = 0,
            max = 3500,
            bigStep = 0.50,
            order = 102
        },
        y = {
            type = 'range',
            name = 'Y',
            desc = 'Y relative to BOTTOM LEFT' .. getDefaultStr('y'),
            min = 0,
            max = 3500,
            bigStep = 0.50,
            order = 102
        },
        sizeX = {
            type = 'range',
            name = 'Size X',
            desc = 'Size X' .. getDefaultStr('sizeX'),
            min = 0,
            max = 1000,
            bigStep = 0.50,
            order = 103
        },
        sizeY = {
            type = 'range',
            name = 'Size Y',
            desc = 'Size Y' .. getDefaultStr('sizeY'),
            min = 0,
            max = 1000,
            bigStep = 0.50,
            order = 103
        }
    }
}

function Module:OnInitialize()
    DF:Debug(self, 'Module ' .. mName .. ' OnInitialize()')
    self.db = DF.db:RegisterNamespace(mName, defaults)
    db = self.db.profile

    self:SetEnabledState(DF:GetModuleEnabled(mName))
    DF:RegisterModuleOptions(mName, options)
end

function Module:OnEnable()
    DF:Debug(self, 'Module ' .. mName .. ' OnEnable()')
    Module.Wrath()
    Module:ApplySettings()
end

function Module:OnDisable()
end

function Module:ApplySettings()
    db = Module.db.profile
    if not db then return end

    local x = db.x or defaults.profile.x or 42
    local y = db.y or defaults.profile.y or 35
    local w = db.sizeX or defaults.profile.sizeX or 460
    local h = db.sizeY or defaults.profile.sizeY or 207

    ChatFrame1:ClearAllPoints()
    ChatFrame1:SetPoint('BOTTOMLEFT', UIParent, 'BOTTOMLEFT', x, y)
    ChatFrame1:SetSize(w, h)
    ChatFrame1:SetUserPlaced(true)

    if FCF_SavePositionAndDimensions then
        FCF_SavePositionAndDimensions(ChatFrame1)
    end
end

local frame = CreateFrame('FRAME', 'ImprovedUIChatFrame', UIParent)

function Module.ChangeSizeAndPosition()
    Module:ApplySettings()
end

function frame:OnEvent(event, arg1)
    if event == 'PLAYER_ENTERING_WORLD' then
        if GetCVar("chatBubbles") == nil then
            SetCVar("chatBubbles", "1")
        end
        if GetCVar("chatBubblesParty") == nil then
            SetCVar("chatBubblesParty", "1")
        end
        Module:ApplySettings()
    end
end
frame:SetScript('OnEvent', frame.OnEvent)

function Module.Wrath()
    Module.ChangeSizeAndPosition()

    frame:RegisterEvent('PLAYER_ENTERING_WORLD')
end
