--[[
    ProjectJaina_Companion — Core.lua
    Motor central del hub social de Project Jaina.

    Funcionalidades:
    1. Detecta qué addons Project Jaina tiene activo cada miembro del grupo vía P2P (WP_COMP).
    2. Anuncia en el canal de grupo cuando un jugador sube de nivel en el BattlePass.
    3. Muestra el badge de modo de juego (Hardcore/Ironman/Normal) del jugador local.
    4. Resiliencia contra reseteo de WTF en cabinas de internet mediante escaneo de auras.

    RESTRICCIONES 3.3.5a:
    - RegisterAddonMessagePrefix es defensivo.
    - Sin C_Timer.After: usa OnUpdate con elapsed.
    - SetTexture de color usa WHITE8X8 + SetVertexColor.
    - Zero heap thrashing: reuso de timers, sin CreateFrame dinámico en cada evento.
]]

-- ================================================================
-- SYSTEM HOTFIX: FrameXML / ChatFrame CHANNEL_NOTICE Nil Guard
-- Protege contra crash en ChatFrame.lua:2802 si el servidor envía notices no definidas en GlobalStrings
-- ================================================================
if not _G.CHAT_NOT_IN_LFG_NOTICE then
    _G.CHAT_NOT_IN_LFG_NOTICE = "|Hchannel:%d|h[%s]|h Debes unirte a la cola de Buscar grupo para poder participar en este canal."
end
if not _G.CHAT_NOT_IN_LFG_NOTICE_BN then
    _G.CHAT_NOT_IN_LFG_NOTICE_BN = "|Hchannel:CHANNEL:%d|h[%s]|h Debes unirte a la cola de Buscar grupo para poder participar en este canal."
end

local _Orig_ChatFrame_MessageEventHandler = _G.ChatFrame_MessageEventHandler
if _Orig_ChatFrame_MessageEventHandler then
    _G.ChatFrame_MessageEventHandler = function(self, event, ...)
        if event == "CHAT_MSG_CHANNEL_NOTICE" or event == "CHAT_MSG_CHANNEL_NOTICE_USER" then
            local noticeType = ...
            if noticeType then
                local bnKey = "CHAT_" .. tostring(noticeType) .. "_NOTICE_BN"
                local stdKey = "CHAT_" .. tostring(noticeType) .. "_NOTICE"
                if not _G[bnKey] and not _G[stdKey] then
                    _G[stdKey] = "|Hchannel:%d|h[%s]|h [" .. tostring(noticeType) .. "]"
                end
            end
        end
        return _Orig_ChatFrame_MessageEventHandler(self, event, ...)
    end
end

ProjectJaina_Companion = ProjectJaina_Companion or {}
local C = ProjectJaina_Companion

-- ================================================================
-- ESTADO EN MEMORIA
-- ================================================================
local groupAddonStatus = {}   -- [playerName] = { addons = {...}, mode = "...", time = GetTime() }
local lastBPLevel      = 0   -- nivel propio en BattlePass
local addonLoaded      = false

-- Timers defensivos (reutilizados en el OnUpdate principal)
local tickElapsed            = 0
local TICK_INTERVAL          = 5
local rosterTimer            = 0
local rosterDebounceActive   = false

-- ================================================================
-- UTILIDADES
-- ================================================================
local function CPrint(msg)
    local f = DEFAULT_CHAT_FRAME or ChatFrame1
    if f and f.AddMessage then
        f:AddMessage("|cFFD4AF37[Project Jaina]|r " .. tostring(msg))
    end
end

local function IsAddonLoaded(name)
    if not name or not _G.IsAddOnLoaded then return false end
    local loaded = _G.IsAddOnLoaded(name)
    if not loaded and not name:find("^ProjectJaina_") then
        loaded = _G.IsAddOnLoaded("ProjectJaina_" .. name)
    end
    return (loaded and true) or false
end

local function GetLocalGameMode()
    if ProjectJaina_GameModes_CharDB
       and ProjectJaina_GameModes_CharDB.hasSelectedMode
       and ProjectJaina_GameModes_CharDB.selectedMode then
        return ProjectJaina_GameModes_CharDB.selectedMode
    end

    -- Fallback resiliente a cabinas de internet (WTF reseteado): Escanear auras del servidor
    for i = 1, 40 do
        local auraName = UnitAura("player", i)
        if not auraName then break end
        local lower = auraName:lower()
        if lower:find("hardcore") then
            if ProjectJaina_GameModes_CharDB then
                ProjectJaina_GameModes_CharDB.hasSelectedMode = true
                ProjectJaina_GameModes_CharDB.selectedMode = "HARDCORE"
            end
            return "HARDCORE"
        elseif lower:find("ironman") then
            if ProjectJaina_GameModes_CharDB then
                ProjectJaina_GameModes_CharDB.hasSelectedMode = true
                ProjectJaina_GameModes_CharDB.selectedMode = "IRONMAN"
            end
            return "IRONMAN"
        elseif lower:find("die and rise") or lower:find("dierise") then
            if ProjectJaina_GameModes_CharDB then
                ProjectJaina_GameModes_CharDB.hasSelectedMode = true
                ProjectJaina_GameModes_CharDB.selectedMode = "DIE_AND_RISE"
            end
            return "DIE_AND_RISE"
        end
    end
    return "NORMAL"
end

-- ================================================================
-- DETECCIÓN UNIFICADA DE CANAL DE GRUPO (PVE + PVP BATTLEGROUNDS)
-- ================================================================
local function GetGroupChannel()
    if IsInInstance then
        local inInstance, instanceType = IsInInstance()
        if inInstance and instanceType == "pvp" then
            return "BATTLEGROUND"
        end
    end
    if GetNumRaidMembers and GetNumRaidMembers() > 0 then
        return "RAID"
    elseif GetNumPartyMembers and GetNumPartyMembers() > 0 then
        return "PARTY"
    end
    return nil
end

-- ================================================================
-- ANUNCIO AL GRUPO (LIMPIO DE CÓDIGOS DE COLOR |c)
-- ================================================================
local function AnnounceToGroup(msg)
    local ch = C.Config.AnnounceChannel
    if not ch or ch == "" or ch == "OFF" or ch == "NONE" then return end
    if (ch == "GROUP" or ch == "PARTY") then
        local target = GetGroupChannel()
        if target then
            SendChatMessage(msg, target)
        end
    elseif ch == "SAY" then
        SendChatMessage(msg, "SAY")
    end
end

-- ================================================================
-- LIMPIEZA DE MIEMBROS DESCONECTADOS / GRUPO DISUELTO
-- ================================================================
local function PruneGroupStatus()
    local targetChannel = GetGroupChannel()
    if not targetChannel then
        for k in pairs(groupAddonStatus) do
            groupAddonStatus[k] = nil
        end
        return
    end

    local currentMembers = {}
    local myName = UnitName("player")
    if myName then currentMembers[myName] = true end

    if targetChannel == "RAID" or targetChannel == "BATTLEGROUND" then
        local count = GetNumRaidMembers()
        for i = 1, count do
            local name = UnitName("raid" .. i)
            if name then currentMembers[name] = true end
        end
    elseif targetChannel == "PARTY" then
        local count = GetNumPartyMembers()
        for i = 1, count do
            local name = UnitName("party" .. i)
            if name then currentMembers[name] = true end
        end
    end

    for sender in pairs(groupAddonStatus) do
        local baseName = sender:match("^[^-]+") or sender
        if not currentMembers[sender] and not currentMembers[baseName] then
            groupAddonStatus[sender] = nil
        end
    end
end

-- ================================================================
-- SECCIÓN 1: BROADCAST DE ADDONS ACTIVOS
-- ================================================================
local function BuildMyAddonPayload()
    local active = {}
    for _, entry in ipairs(C.Config.EcosystemAddons) do
        if IsAddonLoaded(entry.name) then
            table.insert(active, entry.label)
        end
    end
    local mode = GetLocalGameMode()
    return string.format("WP_ADDONS:%s|%s", table.concat(active, ","), mode)
end

local function BroadcastStatus()
    local playerName = UnitName("player")
    if not playerName or playerName == "" then return end
    local targetChannel = GetGroupChannel()
    if not targetChannel then return end

    local payload = BuildMyAddonPayload()
    if #payload > 200 then return end  -- guardia estricta de 255 bytes

    if RegisterAddonMessagePrefix then
        RegisterAddonMessagePrefix(C.Config.AddonPrefix or "JAINA_COMP")
        RegisterAddonMessagePrefix(C.Config.LegacyPrefix or "WP_COMP")
    end

    SendAddonMessage(C.Config.AddonPrefix or "JAINA_COMP", payload, targetChannel)
    if C.Config.LegacyPrefix then
        SendAddonMessage(C.Config.LegacyPrefix, payload, targetChannel)
    end
end

-- ================================================================
-- SECCIÓN 2: RECEPCIÓN DE STATUS Y PROTOCOLO P2P BIDIRECCIONAL
-- ================================================================
local responseJitterTimer = 0
local responseJitterTarget = 0
local responsePending = false

local function ParseAddonMessage(sender, message)
    if not sender or sender == "" or not message then return end
    local myName = UnitName("player")
    local baseSender = sender:match("^[^-]+") or sender
    if baseSender == myName or sender == myName then return end

    -- 1. Solicitud de escaneo P2P proveniente de un compañero de grupo/banda
    if message == "JAINA_SCAN_REQ" or message == "WP_SCAN_REQ" then
        -- Responder con jitter defensivo aleatorio para evitar colisiones en bandas de 25/40
        responseJitterTimer = 0
        responseJitterTarget = 0.05 + (math.random(1, 30) / 100)
        responsePending = true
        return
    end

    -- 2. Recepción de estado de un compañero
    -- Formato esperado: "JAINA_ADDONS:<addon1>,<addon2>|<MODE>" o "WP_ADDONS:..."
    local addonList, mode = message:match("^[A-Z_]+_ADDONS:([^|]*)|(.+)$")
    if not addonList then return end

    local addons = {}
    for label in addonList:gmatch("[^,]+") do
        addons[label] = true
    end

    groupAddonStatus[sender] = {
        addons = addons,
        mode   = mode or "NORMAL",
        time   = GetTime(),
    }
end

local function RequestGroupScan()
    local targetChannel = GetGroupChannel()
    if not targetChannel then
        CPrint("No estás en un grupo o banda para escanear.")
        return
    end

    if RegisterAddonMessagePrefix then
        RegisterAddonMessagePrefix(C.Config.AddonPrefix or "JAINA_COMP")
        RegisterAddonMessagePrefix(C.Config.LegacyPrefix or "WP_COMP")
    end

    -- Primero transmitimos nuestro estado
    BroadcastStatus()

    -- Solicitamos a todos los clientes del grupo responder con el suyo
    SendAddonMessage(C.Config.AddonPrefix or "JAINA_COMP", "JAINA_SCAN_REQ", targetChannel)
    if C.Config.LegacyPrefix then
        SendAddonMessage(C.Config.LegacyPrefix, "WP_SCAN_REQ", targetChannel)
    end
    CPrint("Escaneando addons del grupo (solicitud P2P enviada)...")
end

-- ================================================================
-- SECCIÓN 3: DETECCIÓN DE LEVEL-UP EN BATTLEPASS (LOGIN SEGURO)
-- ================================================================
local function CheckBattlePassLevelUp()
    if not Jaina_BattlePass then return end
    local bp = Jaina_BattlePass
    if not bp.Data then return end

    -- Blindaje: Si el BattlePass aún no completa su sincronización inicial con el servidor, no evaluar
    if not bp.Data.hasSyncedOnce then
        return
    end

    local newLevel = bp.Data.level or 0
    if lastBPLevel == 0 then
        -- Primer registro tras sincronización exitosa: no emitir anuncio de login
        lastBPLevel = newLevel
        return
    end

    if newLevel > lastBPLevel then
        local playerName = UnitName("player") or "Desconocido"
        local msg = string.format(
            "[BattlePass] %s alcanzo el Nivel %d del Pase de Batalla! (/bp)",
            playerName, newLevel
        )
        AnnounceToGroup(msg)
        lastBPLevel = newLevel
    end
end

-- ================================================================
-- FORMATO CANÓNICO DE MODOS DE JUEGO (NORMAL, HC, IM, RETO X1)
-- ================================================================
local function FormatModeBadge(mode, short)
    if not mode or mode == "NORMAL" or mode == "NONE" then
        return short and "" or " |cFF888888[NORMAL]|r"
    elseif mode == "HARDCORE" then
        return short and " |cFFFF3333[HC]|r" or " |cFFFF3333[HARDCORE]|r"
    elseif mode == "IRONMAN" then
        return short and " |cFFFF9900[IM]|r" or " |cFFFF9900[IRONMAN]|r"
    elseif mode == "DIE_AND_RISE" or mode == "DIERISE" then
        return short and " |cFFBF5FFF[D&R]|r" or " |cFFBF5FFF[DIE & RISE]|r"
    elseif mode == "SLOW_X1" or mode == "X1" then
        return short and " |cFFFFD100[X1]|r" or " |cFFFFD100[RETO X1]|r"
    end
    return short and string.format(" |cFF00CCFF[%s]|r", tostring(mode)) or string.format(" |cFF00CCFF[%s]|r", tostring(mode))
end

-- ================================================================
-- SECCIÓN 4: INTERFAZ DE COMANDO /companion
-- ================================================================
local function PrintGroupStatus()
    PruneGroupStatus()

    local targetChannel = GetGroupChannel()
    if not targetChannel then
        local myMode = GetLocalGameMode()
        CPrint("No estas en un grupo o banda actualmente.")
        CPrint("Tu modo activo:" .. FormatModeBadge(myMode, false))
        return
    end

    CPrint("--- Estado del Ecosistema Project Jaina en el grupo ---")

    -- Mostrar primero al jugador local
    local myName = UnitName("player") or "Jugador"
    local myMode = GetLocalGameMode()
    local myModeStr = FormatModeBadge(myMode, true)

    local myActive = {}
    for _, entry in ipairs(C.Config.EcosystemAddons) do
        if IsAddonLoaded(entry.name) then
            table.insert(myActive, entry.label)
        end
    end
    table.sort(myActive)
    local myList = (#myActive > 0) and table.concat(myActive, ", ") or "(solo Companion)"
    CPrint(string.format("  %s%s (Tu): %s", myName, myModeStr, myList))

    -- Mostrar compañeros
    local count = 0
    for name, data in pairs(groupAddonStatus) do
        local baseName = name:match("^[^-]+") or name
        if baseName ~= myName and name ~= myName then
            count = count + 1
            local addonNames = {}
            for label in pairs(data.addons) do
                table.insert(addonNames, label)
            end
            table.sort(addonNames)
            local modeStr = FormatModeBadge(data.mode, true)
            local listStr = (#addonNames > 0) and table.concat(addonNames, ", ") or "(solo Companion)"
            CPrint(string.format("  %s%s: %s", name, modeStr, listStr))
        end
    end

    if count == 0 then
        CPrint("  No hay datos de companeros aun. (Usa /companion scan para solicitar)")
    end
end

-- ================================================================
-- CENTRO DE CONTROL: MENÚ DESPLEGABLE NATIVO DEL ECOSISTEMA
-- ================================================================
local hubDropDown = CreateFrame("Frame", "ProjectJainaHubDropDown", UIParent, "UIDropDownMenuTemplate")

local function ExecuteOrWarn(slashKey, fallbackKey, moduleName)
    if SlashCmdList and SlashCmdList[slashKey] then
        SlashCmdList[slashKey]("")
    elseif fallbackKey and SlashCmdList and SlashCmdList[fallbackKey] then
        SlashCmdList[fallbackKey]("")
    elseif moduleName == "Tienda Dalaran" and ProjectJaina_Store and ProjectJaina_Store.Toggle then
        ProjectJaina_Store:Toggle()
    elseif moduleName == "Tienda Visual" and WowPeruVisual_ToggleUI then
        WowPeruVisual_ToggleUI()
    elseif moduleName == "MultiBot" and MultiBot and MultiBot.ToggleMainUIVisibility then
        MultiBot.ToggleMainUIVisibility()
    elseif moduleName == "Chatter LLM" and Chatter and Chatter.Toggle then
        Chatter:Toggle()
    elseif moduleName == "Graficos HD" and ProjectJaina_Graphics and ProjectJaina_Graphics.ToggleUI then
        ProjectJaina_Graphics:ToggleUI()
    else
        CPrint(string.format("|cFFFF4444El modulo %s no esta activo o instalado.|r", moduleName))
    end
end

local function OpenHubMenu(anchor)
    local headerTitle = (C.Progression and C.Progression.name)
        and string.format("|cFFD4AF37Project Jaina|r - %s (Cap %d)", C.Progression.name, C.Progression.levelCap or 60)
        or "|cFFD4AF37Project Jaina|r - Centro de Control"
    local menuList = {
        { text = headerTitle, isTitle = true, notCheckable = true },
        { text = "|cFFFFD100Pase de Batalla|r (/bp)", notCheckable = true, func = function()
            ExecuteOrWarn("JAINA_BP", "WOWPERUBP", "BattlePass")
        end },
        { text = "|cFFFFD100Guardarropa (Transfiguración)|r (/armario)", notCheckable = true, func = function()
            ExecuteOrWarn("JAINA_WARDROBE", "WP_WARDROBEV2", "Guardarropa")
        end },
        { text = "|cFFFFD100Modos de Juego|r (/modos)", notCheckable = true, func = function()
            ExecuteOrWarn("JAINA_MODES", "WOWPERU_MODES", "Modos de Juego")
        end },
        { text = "|cFFFFD100Suite Gráfica HD|r (/graficos)", notCheckable = true, func = function()
            ExecuteOrWarn("JAINA_GRAPHICS", "WOWPERU_GRAPHICS", "Graficos HD")
        end },
        { text = "|cFF00FFCCGestor de Bots con IA|r (/bots)", notCheckable = true, func = function()
            ExecuteOrWarn("CHATTER", "LLMC", "Chatter LLM")
        end },
        { text = "|cFFFFD100Playerbots (MultiBot)|r (/multibot)", notCheckable = true, func = function()
            ExecuteOrWarn("MULTIBOT", "ACECONSOLE_MULTIBOT", "MultiBot")
        end },
        { text = "|cFFD4AF37Barra Táctica de Bots|r (/botbar)", notCheckable = true, func = function()
            if C.ToggleTacticalBar then C.ToggleTacticalBar() end
        end },
        { text = "|cFFFFD100Tesorería de Dalaran|r (/tienda)", notCheckable = true, func = function()
            ExecuteOrWarn("PROJECTJAINA_STORE", "TIENDA", "Tienda Dalaran")
        end },
        { text = "|cFFFFD100Alas y Auras Místicas|r (/alas)", notCheckable = true, func = function()
            ExecuteOrWarn("JAINA_VISUAL", "WOWPERU_VISUAL", "Tienda Visual")
        end },
        { text = "|cFFFFD100LoreHUD (Subtítulos 3D)|r (/lorehud)", notCheckable = true, func = function()
            ExecuteOrWarn("LOREHUD", nil, "LoreHUD")
        end },
        { text = "|cFF00CCFFVoz Espacial 3D|r (/voz)", notCheckable = true, func = function()
            ExecuteOrWarn("PROJECTJAINA_VOZ", "VOZ", "Voz 3D")
        end },
        { text = " ", notCheckable = true, disabled = true },
        { text = "Herramientas de Grupo", hasArrow = true, notCheckable = true,
          menuList = {
              { text = "Solicitar Escaneo P2P", notCheckable = true, func = RequestGroupScan },
              { text = "Imprimir Estado de Companeros", notCheckable = true, func = PrintGroupStatus },
          }
        },
        { text = " ", notCheckable = true, disabled = true },
        { text = "|cFF888888Cerrar|r", notCheckable = true, func = function() end },
    }
    EasyMenu(menuList, hubDropDown, anchor or "cursor", 0, 0, "MENU")
end

SLASH_WPCOMP1 = "/companion"
SLASH_WPCOMP2 = "/wpcomp"
SLASH_WPCOMP3 = "/hub"
SLASH_WPCOMP4 = "/menu"
SLASH_JAINA_COMP1 = "/jainacomp"
SLASH_JAINA_COMP2 = "/comp"
SLASH_WPCOMP5 = "/pjc"
SlashCmdList["WPCOMP"] = function(msg)
    local cmd, arg = (msg or ""):lower():match("^(%S+)%s*(%S*)$")
    cmd = cmd or ""

    if cmd == "menu" or cmd == "hub" or cmd == "" then
        OpenHubMenu("cursor")
    elseif cmd == "focus" then
        C.SendCommand("focus")
    elseif cmd == "revive" or cmd == "sync" then
        C.SendCommand("revive")
    elseif cmd == "scan" then
        RequestGroupScan()
    elseif cmd == "status" then
        PrintGroupStatus()
    elseif cmd == "debug" then
        C.Config.Debug = not C.Config.Debug
        if ProjectJainaCompanion_DB then ProjectJainaCompanion_DB.Debug = C.Config.Debug end
        CPrint("Debug: " .. (C.Config.Debug and "ON" or "OFF"))
    elseif cmd == "channel" then
        if arg == "group" or arg == "party" or arg == "say" then
            C.Config.AnnounceChannel = arg:upper()
            if ProjectJainaCompanion_DB then ProjectJainaCompanion_DB.AnnounceChannel = C.Config.AnnounceChannel end
            CPrint("Canal de anuncios configurado en: " .. C.Config.AnnounceChannel)
        elseif arg == "off" or arg == "none" then
            C.Config.AnnounceChannel = ""
            if ProjectJainaCompanion_DB then ProjectJainaCompanion_DB.AnnounceChannel = "" end
            CPrint("Anuncios desactivados.")
        else
            local cur = (C.Config.AnnounceChannel ~= "") and C.Config.AnnounceChannel or "OFF"
            CPrint("Canal actual: " .. cur)
            CPrint("Uso: /companion channel [group|party|say|off]")
        end
    else
        CPrint("Uso: /companion [status|scan|channel|debug]")
        CPrint("Comandos Cross-Faction: /comerciar y /invitar [Nombre]")
    end
end
SlashCmdList["JAINA_COMP"] = SlashCmdList["WPCOMP"]

-- ================================================================
-- UTILIDADES CROSS-FACTION (Alianza <-> Horda)
-- Permite comerciar e invitar entre facciones opuestas de forma limpia
-- sin modificar UnitPopupMenus de Blizzard (CERO TAINT).
-- ================================================================
SLASH_WPCOMERCIAR1 = "/comerciar"
SLASH_WPCOMERCIAR2 = "/comercio"
SlashCmdList["WPCOMERCIAR"] = function()
    if not UnitExists("target") then
        CPrint("Selecciona a un jugador y escribe |cFFD4AF37/comerciar|r")
        return
    end
    InitiateTrade("target")
end

SLASH_WPINVITAR1 = "/invitar"
SlashCmdList["WPINVITAR"] = function(nombre)
    if nombre and nombre ~= "" then
        InviteUnit(nombre)
        return
    end
    if UnitExists("target") and UnitIsPlayer("target") then
        InviteUnit(UnitName("target"))
        return
    end
    CPrint("Escribe |cFFD4AF37/invitar Nombre|r, o selecciona a un jugador primero.")
end

-- ================================================================
-- BOTÓN DE MINIMAPA OFICIAL CON EL LOGO DE WOW PERÚ
-- ================================================================
local minimapBtn = nil
local DEFAULT_COMPANION_ANGLE = 165
local MINIMAP_RADIUS = 80

local function UpdateMinimapBtnPosition(button, angle)
    local rad = math.rad(angle)
    local x = math.cos(rad) * MINIMAP_RADIUS
    local y = math.sin(rad) * MINIMAP_RADIUS
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function CreateMinimapButton()
    if minimapBtn then return minimapBtn end
    local btn = CreateFrame("Button", "ProjectJaina_CompanionMinimapBtn", Minimap)
    btn:SetSize(31, 31)
    btn:SetFrameStrata("MEDIUM")
    btn:SetFrameLevel(8)
    btn:EnableMouse(true)
    btn:SetMovable(true)
    btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    btn:RegisterForDrag("LeftButton", "RightButton")
    btn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local icon = btn:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", btn, "CENTER", 0, 0)
    icon:SetTexture("Interface\\AddOns\\ProjectJaina_Companion\\Textures\\jaina_icon.tga")

    local border = btn:CreateTexture(nil, "OVERLAY")
    border:SetSize(52, 52)
    border:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 0)
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

    local wasDragged = false
    local function OnDragUpdate(self)
        local mx, my = Minimap:GetCenter()
        local px, py = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        px, py = px / scale, py / scale

        local angle = math.deg(math.atan2(py - my, px - mx))
        if angle < 0 then angle = angle + 360 end

        ProjectJaina_Companion_DB = ProjectJaina_Companion_DB or ProjectJainaCompanion_DB or {}
            ProjectJainaCompanion_DB = ProjectJaina_Companion_DB
        ProjectJainaCompanion_DB.minimapAngle = angle

        UpdateMinimapBtnPosition(self, angle)
        wasDragged = true
    end

    btn:SetScript("OnDragStart", function(self)
        wasDragged = false
        self:LockHighlight()
        self:SetScript("OnUpdate", OnDragUpdate)
    end)

    btn:SetScript("OnDragStop", function(self)
        self:UnlockHighlight()
        self:SetScript("OnUpdate", nil)
    end)

    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cFFD4AF37Project Jaina Companion|r", 1, 1, 1)
        GameTooltip:AddLine("Centro de Control del Ecosistema", 0.8, 0.8, 0.8)
        if C.Progression and C.Progression.name then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine(string.format("|cFFD4AF37Era del Reino:|r |cff39d353%s|r", C.Progression.name), 1, 1, 1)
            GameTooltip:AddLine(string.format("|cFFD4AF37Tope de Nivel:|r |cffffd700%d|r", C.Progression.levelCap or 60), 0.9, 0.9, 0.9)
        end
        GameTooltip:AddLine("|cFF888888Desarrollo: DarckRovert (Elnazzareno)|r", 0.7, 0.7, 0.7)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cFFFFD100Click Izquierdo:|r Abrir Menú Central de Project Jaina", 0.2, 1, 0.2)
        GameTooltip:AddLine("|cFFFFD100Click Derecho:|r Imprimir estado de compañeros P2P", 0.2, 0.8, 1)
        GameTooltip:AddLine("|cFF888888Arrastrar para reposicionar|r", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    btn:SetScript("OnClick", function(self, button)
        if wasDragged then
            wasDragged = false
            return
        end
        if button == "RightButton" then
            PrintGroupStatus()
        else
            OpenHubMenu("cursor")
        end
    end)

    local savedAngle = (ProjectJainaCompanion_DB and ProjectJainaCompanion_DB.minimapAngle) or DEFAULT_COMPANION_ANGLE
    UpdateMinimapBtnPosition(btn, savedAngle)

    minimapBtn = btn
    return btn
end

-- ================================================================
-- EVENTO FRAME PRINCIPAL (ZERO HEAP ALLOCATION)
-- ================================================================
local eventFrame = CreateFrame("Frame", "ProjectJainaCompanion_Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("CHAT_MSG_ADDON")
eventFrame:RegisterEvent("RAID_ROSTER_UPDATE")
eventFrame:RegisterEvent("PARTY_MEMBERS_CHANGED")

eventFrame:SetScript("OnUpdate", function(self, elapsed)
    if not addonLoaded then return end

    -- Ticker liviano para revisar BattlePass level-up (cada 5 seg)
    tickElapsed = tickElapsed + elapsed
    if tickElapsed >= TICK_INTERVAL then
        tickElapsed = 0
        CheckBattlePassLevelUp()
    end

    -- Debounce de Roster Update (Zero heap allocation, cero fugas de frames)
    if rosterDebounceActive then
        rosterTimer = rosterTimer + elapsed
        if rosterTimer >= 2.0 then
            rosterDebounceActive = false
            rosterTimer = 0
            PruneGroupStatus()
            BroadcastStatus()
        end
    end

    -- Despacho con jitter para respuesta a solicitud WP_SCAN_REQ
    if responsePending then
        responseJitterTimer = responseJitterTimer + elapsed
        if responseJitterTimer >= responseJitterTarget then
            responsePending = false
            responseJitterTimer = 0
            BroadcastStatus()
        end
    end
end)

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local name = ...
        if name == "ProjectJaina_Companion" or name == "ProjectJaina_Companion" then
            addonLoaded = true
            -- Cargar DB persistente
            ProjectJaina_Companion_DB = ProjectJaina_Companion_DB or ProjectJainaCompanion_DB or {}
            ProjectJainaCompanion_DB = ProjectJaina_Companion_DB
            if ProjectJainaCompanion_DB.AnnounceChannel ~= nil then
                C.Config.AnnounceChannel = ProjectJainaCompanion_DB.AnnounceChannel
            end
            if ProjectJainaCompanion_DB.Debug ~= nil then
                C.Config.Debug = ProjectJainaCompanion_DB.Debug
            end
            if ProjectJainaCompanion_DB.Progression then
                C.Progression = ProjectJainaCompanion_DB.Progression
            end
            CreateMinimapButton()
            if C.CreateTacticalBar then C.CreateTacticalBar() end
            CPrint("v" .. C.Config.Version .. " cargado. Usa /companion o /botbar")
        end

    elseif event == "PLAYER_ENTERING_WORLD" then
        if RegisterAddonMessagePrefix then
            RegisterAddonMessagePrefix(C.Config.AddonPrefix)
            RegisterAddonMessagePrefix("JAINA_PHASE_SYNC")
        end
        -- Solicitar estado de progresión temporal del reino al servidor
        local pName = UnitName("player")
        if pName and pName ~= "" and pName ~= UNKNOWNOBJECT then
            SendAddonMessage("JAINA_PHASE_SYNC", "REQ_SYNC", "WHISPER", pName)
        end
        -- Inicializar nivel base de BattlePass si ya completó sync
        if Jaina_BattlePass and Jaina_BattlePass.Data and Jaina_BattlePass.Data.hasSyncedOnce then
            lastBPLevel = Jaina_BattlePass.Data.level or 0
        else
            lastBPLevel = 0
        end
        -- Anunciar status si entra al mundo en grupo
        BroadcastStatus()

    elseif event == "CHAT_MSG_ADDON" then
        local prefix, message, channel, sender = ...
        if prefix == C.Config.AddonPrefix or prefix == (C.Config.LegacyPrefix or "WP_COMP") then
            ParseAddonMessage(sender, message)
        end

        -- Escuchar confirmación autoritativa de modo de juego para actualizar grupo de inmediato
        if (prefix == "JAINA_GAMEMODE" or prefix == "WP_GAMEMODE") and message then
            local mode = message:match("^STATUS:([^:]+)") or message:match("^ACK:([^:]+)")
            if mode then
                if ProjectJaina_GameModes_CharDB then
                    if mode == "NONE" then
                        ProjectJaina_GameModes_CharDB.hasSelectedMode = false
                        ProjectJaina_GameModes_CharDB.selectedMode = nil
                    else
                        ProjectJaina_GameModes_CharDB.hasSelectedMode = true
                        ProjectJaina_GameModes_CharDB.selectedMode = mode
                    end
                end
                BroadcastStatus()
            end
        end

        -- Escuchar paquetes de BattlePass para sincronizar inmediato tras XP real
        if (prefix == "JAINA_BP" or prefix == "WP_BP") and message then
            local opcode = message:match("^([^:]+)")
            if opcode == "BP_RES_XP" then
                -- Acelerar ticker para comprobar inmediatamente tras procesar el levelup
                tickElapsed = TICK_INTERVAL - 0.1
            end
        end

        -- Escuchar sincronización autoritativa de fase del reino
        if prefix == "JAINA_PHASE_SYNC" and message then
            local op, phaseId, levelCap, phaseName = message:match("^([^:]+):([^:]+):([^:]+):(.+)$")
            if op == "SYNC" then
                C.Progression = {
                    phase = phaseId,
                    levelCap = tonumber(levelCap) or 60,
                    name = phaseName or "World of Warcraft Classic"
                }
                ProjectJaina_Companion_DB = ProjectJaina_Companion_DB or {}
                ProjectJaina_Companion_DB.Progression = C.Progression
            end
        end

    elseif event == "RAID_ROSTER_UPDATE" or event == "PARTY_MEMBERS_CHANGED" then
        PruneGroupStatus()
        -- Resetear el timer de debounce para no spamear en formaciones masivas de raid
        rosterTimer = 0
        rosterDebounceActive = true
    end
end)

-- ================================================================
-- CONTROL TÁCTICO DE PLAYERBOTS (Project Jaina v2.0)
-- Barra flotante de comandos rápidos, keybindings nativos y reclutamiento por rol
-- ================================================================
_G["BINDING_HEADER_PROJECTJAINA_COMPANION"] = "|cFFD4AF37Project Jaina|r - Control Táctico"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_FOLLOW"] = "Bots: Seguir"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_STAY"] = "Bots: Quedarse / Alto"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_ATTACK"] = "Bots: Atacar objetivo"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_FOCUS"] = "Bots: Concentrar Fuego (Focus Fire / Calavera)"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_REVIVE"] = "Bots: Reanimar / Sincronizar Escuadrón (.rdf revive)"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_PULL"] = "Bots: Auto-Pull (Tanque)"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_PASSIVE"] = "Bots: Modo Pasivo"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_RECRUIT_TANK"] = "Reclutar Bot: Tanque"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_RECRUIT_HEALER"] = "Reclutar Bot: Sanador"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_RECRUIT_DPS"] = "Reclutar Bot: DPS"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_REGEAR"] = "Bots: Reequipar / Actualizar Equipo"
_G["BINDING_NAME_PROJECTJAINA_COMPANION_TOGGLEBAR"] = "Alternar Barra Táctica de Bots"

function C.SendCommand(action, arg)
    if not action then return end
    local groupChannel = GetGroupChannel()
    local isFriendlyPlayer = UnitExists("target") and UnitIsPlayer("target") and UnitIsFriend("player", "target")
    local targetBotName = isFriendlyPlayer and UnitName("target")

    local function DispatchOrder(cmd, desc)
        if targetBotName then
            SendChatMessage(cmd, "WHISPER", nil, targetBotName)
            CPrint("|cFF00FFCCOrden táctica a |cFFFFD100" .. targetBotName .. "|r: |cFFFFFF00" .. cmd .. "|r")
            return
        end

        if groupChannel then
            SendChatMessage(cmd, groupChannel)
            if desc then CPrint(desc) end
            return
        end

        CPrint("|cFFFF3333No estás en un grupo con bots ni tienes un bot aliado seleccionado como objetivo.|r")
    end

    if action == "follow" then
        DispatchOrder("follow", "|cFF00FFCCEscuadrón:|r Siguiendo al líder.")
    elseif action == "stay" then
        DispatchOrder("stay", "|cFF00FFCCEscuadrón:|r Alto / Esperando en posición.")
    elseif action == "attack" then
        if groupChannel then
            SendChatMessage("attack", groupChannel)
            if UnitExists("target") and UnitCanAttack("player", "target") then
                CPrint("|cFF00FFCCEscuadrón:|r Atacando a |cFFFFD100" .. (UnitName("target") or "Objetivo") .. "|r.")
            end
        elseif targetBotName then
            SendChatMessage("attack", "WHISPER", nil, targetBotName)
            CPrint("|cFF00FFCCOrden de ataque individual enviada a |cFFFFD100" .. targetBotName .. "|r.")
        else
            CPrint("|cFFFF3333No tienes un grupo de bots para ordenar un ataque coordinado.|r")
        end
    elseif action == "focus" then
        if groupChannel then
            if UnitExists("target") and UnitCanAttack("player", "target") then
                pcall(function() SetRaidTarget("target", 8) end)
                SendChatMessage("+focus,attack", groupChannel)
                CPrint("|cFF00FFCCFoco Táctico activado:|r Escuadrón concentrando fuego en |cFFFFD100" .. (UnitName("target") or "Objetivo") .. "|r.")
            else
                SendChatMessage("+focus", groupChannel)
                CPrint("|cFF00FFCCEstrategia de Foco Táctico enviada al escuadrón.|r")
            end
        elseif targetBotName then
            if UnitExists("target") and UnitCanAttack("player", "target") then
                SendChatMessage("+focus,attack", "WHISPER", nil, targetBotName)
                CPrint("|cFF00FFCCFoco individual enviado a |cFFFFD100" .. targetBotName .. "|r.")
            else
                SendChatMessage("+focus", "WHISPER", nil, targetBotName)
            end
        else
            CPrint("|cFFFF3333No tienes un grupo de bots para ordenar foco táctico.|r")
        end
    elseif action == "revive" or action == "sync" then
        SendChatMessage(".rdf revive", "SAY")
        CPrint("|cFF00FFCCSincronización de Escuadrón:|r Reanimando y teletransportando bots caídos a tu posición...")
    elseif action == "pull" then
        if groupChannel then
            SendChatMessage("pull", groupChannel)
            CPrint("|cFF00FFCCAuto-Pull activado:|r El bot tanque inicia el pull táctico.")
        elseif targetBotName then
            SendChatMessage("pull", "WHISPER", nil, targetBotName)
            CPrint("|cFF00FFCCAuto-Pull individual enviado a |cFFFFD100" .. targetBotName .. "|r.")
        else
            CPrint("|cFFFF3333No tienes un grupo de bots para ordenar un pull táctico.|r")
        end
    elseif action == "passive" then
        DispatchOrder("flee", "|cFF00FFCCEscuadrón en Modo Pasivo:|r Alto el fuego y repliegue.")
    elseif action == "recruit_tank" then
        SendChatMessage(".bot role tank", "SAY")
    elseif action == "recruit_healer" then
        SendChatMessage(".bot role heal", "SAY")
    elseif action == "recruit_dps" then
        SendChatMessage(".bot role dps", "SAY")
    elseif action == "regear" then
        SendChatMessage(".bot regear", "SAY")
    elseif action == "raid" then
        local size = arg or "5"
        SendChatMessage(".bot raid " .. tostring(size), "SAY")
    end
end

local tacticalBar = nil
local recruitMenu = nil

function C.ToggleTacticalBar()
    if not tacticalBar then
        C.CreateTacticalBar()
    end
    if tacticalBar:IsShown() then
        tacticalBar:Hide()
        if ProjectJaina_Companion_DB then ProjectJaina_Companion_DB.BarHidden = true end
    else
        tacticalBar:Show()
        if ProjectJaina_Companion_DB then ProjectJaina_Companion_DB.BarHidden = false end
    end
end

function C.ToggleRecruitMenu(anchorFrame)
    if not recruitMenu then
        recruitMenu = CreateFrame("Frame", "ProjectJaina_RecruitMenu", UIParent)
        recruitMenu:SetSize(140, 164)
        recruitMenu:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8X8",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 16, edgeSize = 10,
            insets = { left = 2, right = 2, top = 2, bottom = 2 }
        })
        recruitMenu:SetBackdropColor(0.04, 0.05, 0.08, 0.95)
        recruitMenu:SetBackdropBorderColor(0.83, 0.69, 0.22, 1.0)
        recruitMenu:SetFrameStrata("DIALOG")

        local items = {
            { text = "|cFF0070DETanque (Tank)|r", cmd = "recruit_tank" },
            { text = "|cFF00FF00Sanador (Healer)|r", cmd = "recruit_healer" },
            { text = "|cFFFF2020DPS|r", cmd = "recruit_dps" },
            { text = "|cFFFFD100Grupo 5 (5-man)|r", cmd = "raid", arg = 5 },
            { text = "|cFFFF8000Banda 10 (10-man)|r", cmd = "raid", arg = 10 },
            { text = "|cFF9932CCBanda 25 (25-man)|r", cmd = "raid", arg = 25 },
        }

        for i, item in ipairs(items) do
            local b = CreateFrame("Button", nil, recruitMenu)
            b:SetSize(130, 22)
            b:SetPoint("TOP", recruitMenu, "TOP", 0, -6 - (i - 1) * 24)

            local fontStr = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            fontStr:SetPoint("LEFT", b, "LEFT", 8, 0)
            fontStr:SetText(item.text)

            local highlight = b:CreateTexture(nil, "HIGHLIGHT")
            highlight:SetAllPoints()
            highlight:SetTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
            highlight:SetAlpha(0.35)

            b:SetScript("OnClick", function()
                C.SendCommand(item.cmd, item.arg)
                recruitMenu:Hide()
            end)
        end
    end

    if recruitMenu:IsShown() then
        recruitMenu:Hide()
    else
        recruitMenu:ClearAllPoints()
        recruitMenu:SetPoint("BOTTOMLEFT", anchorFrame, "TOPLEFT", 0, 8)
        recruitMenu:Show()
    end
end

function C.CreateTacticalBar()
    if tacticalBar then return end

    tacticalBar = CreateFrame("Frame", "ProjectJaina_TacticalBar", UIParent)
    tacticalBar:SetSize(318, 46)
    tacticalBar:SetPoint("CENTER", UIParent, "CENTER", 0, -220)
    tacticalBar:SetMovable(true)
    tacticalBar:EnableMouse(true)
    tacticalBar:RegisterForDrag("LeftButton")
    tacticalBar:SetScript("OnDragStart", tacticalBar.StartMoving)
    tacticalBar:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint()
        ProjectJaina_Companion_DB = ProjectJaina_Companion_DB or {}
        ProjectJaina_Companion_DB.TacticalPos = { point, relPoint, x, y }
    end)
    tacticalBar:SetClampedToScreen(true)

    tacticalBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    })
    tacticalBar:SetBackdropColor(0.04, 0.06, 0.10, 0.90)
    tacticalBar:SetBackdropBorderColor(0.83, 0.69, 0.22, 0.95)

    local title = tacticalBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    title:SetPoint("TOPLEFT", tacticalBar, "TOPLEFT", 8, -4)
    title:SetText("|cFFD4AF37JAINA|r Táctico")

    local btnDefs = {
        { name = "Follow", tip = "Seguir (Follow)\n|cFF888888Ordena a los bots seguirte de cerca.|r", icon = "Interface\\Icons\\Ability_Tracking", cmd = "follow" },
        { name = "Stay", tip = "Alto / Esperar (Stay)\n|cFF888888Mantiene a los bots en su posición actual.|r", icon = "Interface\\Icons\\Spell_Nature_StoneClawTotem", cmd = "stay" },
        { name = "Attack", tip = "Atacar Objetivo (Attack)\n|cFF888888Ordena a los bots atacar a tu objetivo actual.|r", icon = "Interface\\Icons\\Ability_DualWield", cmd = "attack" },
        { name = "Focus", tip = "Concentrar Fuego (Focus Fire)\n|cFF888888Marca con Calavera y ordena a todos los bots concentrar fuego en tu objetivo actual.|r", icon = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_8", cmd = "focus" },
        { name = "Revive", tip = "Reanimar Escuadrón (Wipe Recovery)\n|cFF888888Reanima y teletransporta a todos los bots caídos o rezagados directo a tu posición (.rdf revive).|r", icon = "Interface\\Icons\\Spell_Holy_Resurrection", cmd = "revive" },
        { name = "Pull", tip = "Auto-Pull del Tanque\n|cFF888888El bot tanque inicia el pull de forma táctica.|r", icon = "Interface\\Icons\\Ability_Hunter_SniperShot", cmd = "pull" },
        { name = "Passive", tip = "Modo Pasivo\n|cFF888888Detiene el combate de los bots inmediatamente.|r", icon = "Interface\\Icons\\Spell_Holy_Peace", cmd = "passive" },
        { name = "Recruit", tip = "Reclutar Bot\n|cFF888888Click izquierdo: Menú de roles.\nClick derecho: Reclutar Tanque.|r", icon = "Interface\\Icons\\Achievement_Reputation_01", isRecruit = true },
        { name = "Regear", tip = "Reequipar (Regear)\n|cFF888888Actualiza y optimiza el equipo del bot seleccionado.|r", icon = "Interface\\Icons\\INV_Hammer_20", cmd = "regear" },
    }

    local btnSize = 28
    local startX = 6
    for i, def in ipairs(btnDefs) do
        local btn = CreateFrame("Button", "PJ_TacticalBtn_" .. def.name, tacticalBar)
        btn:SetSize(btnSize, btnSize)
        btn:SetPoint("BOTTOMLEFT", tacticalBar, "BOTTOMLEFT", startX + (i - 1) * (btnSize + 6), 5)

        local tex = btn:CreateTexture(nil, "BACKGROUND")
        tex:SetAllPoints()
        tex:SetTexture(def.icon)
        btn.icon = tex

        local highlight = btn:CreateTexture(nil, "HIGHLIGHT")
        highlight:SetAllPoints()
        highlight:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
        highlight:SetBlendMode("ADD")

        btn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:ClearLines()
            GameTooltip:AddLine("|cFFD4AF37" .. def.name .. "|r")
            GameTooltip:AddLine(def.tip, 1, 1, 1, true)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)

        if def.isRecruit then
            btn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
            btn:SetScript("OnClick", function(self, button)
                if button == "RightButton" then
                    C.SendCommand("recruit_tank")
                else
                    C.ToggleRecruitMenu(self)
                end
            end)
        else
            btn:SetScript("OnClick", function()
                C.SendCommand(def.cmd)
            end)
        end
    end

    local closeBtn = CreateFrame("Button", nil, tacticalBar, "UIPanelCloseButton")
    closeBtn:SetSize(20, 20)
    closeBtn:SetPoint("TOPRIGHT", tacticalBar, "TOPRIGHT", 2, 2)
    closeBtn:SetScript("OnClick", function()
        tacticalBar:Hide()
        if ProjectJaina_Companion_DB then ProjectJaina_Companion_DB.BarHidden = true end
    end)

    if ProjectJaina_Companion_DB and ProjectJaina_Companion_DB.TacticalPos then
        local pos = ProjectJaina_Companion_DB.TacticalPos
        tacticalBar:ClearAllPoints()
        tacticalBar:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    end

    if ProjectJaina_Companion_DB and ProjectJaina_Companion_DB.BarHidden ~= nil then
        if ProjectJaina_Companion_DB.BarHidden then
            tacticalBar:Hide()
        else
            tacticalBar:Show()
        end
    else
        -- Prevencion de colision visual: Si MultiBot esta cargado, ocultar por defecto la barra tactica
        if IsAddOnLoaded and (IsAddOnLoaded("ProjectJaina_MultiBot") or IsAddOnLoaded("MultiBot")) then
            tacticalBar:Hide()
            if ProjectJaina_Companion_DB then ProjectJaina_Companion_DB.BarHidden = true end
        else
            tacticalBar:Show()
        end
    end
end

SLASH_PROJECTJAINA_BOTBAR1 = "/jainabot"
SLASH_PROJECTJAINA_BOTBAR2 = "/jainacompanion"
SLASH_PROJECTJAINA_BOTBAR3 = "/botbar"
SLASH_PROJECTJAINA_BOTBAR4 = "/pjc"
SLASH_PROJECTJAINA_BOTBAR5 = "/companion"
SLASH_PROJECTJAINA_BOTBAR6 = "/vendetta"
SlashCmdList["PROJECTJAINA_BOTBAR"] = function(msg)
    local cmd = (msg or ""):lower():match("^%s*(%S+)")
    if cmd == "follow" or cmd == "stay" or cmd == "attack" or cmd == "focus" or cmd == "revive" or cmd == "sync" or cmd == "pull" or cmd == "passive" or cmd == "regear" then
        C.SendCommand(cmd)
    elseif cmd == "vendetta" or cmd == "vendettas" or cmd == "caza" or cmd == "caceria" then
        CPrint("|cFFFF0000=== Sistema de Vendetta de Hermandad (Ojo por Ojo) ===|r")
        CPrint("Gobernanza activa: Si un jugador asesina a un Playerbot en PvP abierto de mundo, el clan del bot abatido declara una deuda de sangre.")
        CPrint("Reglas de honor: Un escuadrón de 2-3 cazadores te buscará en el mundo. La vendetta se sacia con |cFF00FF001 muerte del asesino|r o expira tras |cFF00FF0015 minutos de supervivencia|r.")
        CPrint("Cofradías autónomas: <La Cofradía de la Espada Negra>, <Los Centinelas de la Aurora>, <Pacto de Sangre de Kalimdor>, <El Sindicato de Trinquete>, <Custodios de los Arcanos>, <Hijos del Invierno>.")
    elseif cmd == "recruit" then
        local sub = (msg or ""):lower():match("recruit%s+(%S+)")
        if sub == "tank" then C.SendCommand("recruit_tank")
        elseif sub == "healer" or sub == "heal" then C.SendCommand("recruit_healer")
        elseif sub == "dps" then C.SendCommand("recruit_dps")
        else C.ToggleRecruitMenu(tacticalBar or UIParent)
        end
    else
        C.ToggleTacticalBar()
    end
end

