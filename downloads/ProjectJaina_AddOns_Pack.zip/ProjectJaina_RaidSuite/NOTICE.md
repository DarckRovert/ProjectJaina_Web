# 📜 Aviso Legal y Atribución — ProjectJaina_RaidSuite

Este repositorio forma parte del ecosistema oficial de combate y banda de **Project Jaina - Project Jaina**.
Contiene la edición definitiva multiclase del asistente de raid y combate para World of Warcraft 3.3.5a (Build 12340).

---

## 1. Genealogía y Reconocimiento a Obras Precursoras
* **Inspiración Original:** El legendario addon **Necrosis LDC** (creado originalmente por Lomig y TiLt para brujos en WoW clásico/TBC).
* **Evolución Jaina:** Expansión conceptual que llevó la mecánica esférica y botones de acción contextual a las 10 clases del juego.
* **Consolidación y Edición Definitiva Project Jaina:** DarckRovert & Antigravity (Mythos 5). Re-ingeniería completa de menús radiales, contadores de componentes, invocaciones y compatibilidad con WotLK 3.3.5a.

---

## 2. Alcance Arquitectónico
* Soporte nativo para las 10 clases jugables de Wrath of the Lich King.
* Cálculo inteligente de piedras de alma, fragmentos, venenos, tótems, runas y bendiciones de clase.
* Menús contextuales protegidos contra taint durante combate mediante el uso de `SecureActionButtonTemplate`.

---

## 3. Licencia
Distribuido bajo licencia comunitaria abierta [MIT](LICENSE).
