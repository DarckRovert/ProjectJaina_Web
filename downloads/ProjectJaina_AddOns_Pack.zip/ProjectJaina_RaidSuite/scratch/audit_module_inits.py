import os, re

toc_path = r"d:\Project Jaina\Client\Interface\AddOns\Jaina_RaidSuite\ProjectJaina_RaidSuite.toc"
with open(toc_path, 'r', encoding='utf-8') as f:
    toc_lines = [line.strip() for line in f if line.strip() and not line.strip().startswith('#') and not line.strip().startswith('##')]

print(f"Total TOC files: {len(toc_lines)}")

suite_dir = r"d:\Project Jaina\Client\Interface\AddOns\ProjectJaina_RaidSuite"

# Leer todos los archivos para buscar inicializaciones
all_content = {}
for root, dirs, files in os.walk(suite_dir):
    for file in files:
        if file.endswith('.lua'):
            p = os.path.join(root, file)
            with open(p, 'r', encoding='utf-8', errors='ignore') as lf:
                all_content[p] = lf.read()

for toc_file in toc_lines:
    if not toc_file.endswith('.lua'):
        continue
    full_path = os.path.join(suite_dir, toc_file)
    if not os.path.exists(full_path):
        continue
    with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    # Detectar el nombre del módulo en S.<Name>
    m_names = re.findall(r'\b(?:S|Sequito)\.([A-Za-z0-9_]+)\s*=', content)
    # Detectar si tiene su propio PLAYER_LOGIN o ADDON_LOADED o similar
    has_own_loader = bool(re.search(r'PLAYER_LOGIN|ADDON_LOADED|VARIABLES_LOADED|PLAYER_ENTERING_WORLD', content))
    
    # Verificar si se llama a Initialize desde fuera
    called_init = False
    for p, c in all_content.items():
        if p == full_path:
            continue
        for mod_name in m_names:
            if re.search(r'\b' + mod_name + r'[:\.]Initialize\b', c):
                called_init = True
                break
        if called_init:
            break

    # Si no tiene loader propio ni es llamado por fuera
    if not has_own_loader and not called_init:
        # Excluir archivos puramente estáticos o librerías (Spells, Speech, Constants, Theme, etc.)
        if not any(k in toc_file for k in ['Locales', 'Data\\', 'Core\\Constants', 'Core\\Theme']):
            print(f"UNINITIALIZED MODULE: {toc_file} -> Modules: {m_names}")
