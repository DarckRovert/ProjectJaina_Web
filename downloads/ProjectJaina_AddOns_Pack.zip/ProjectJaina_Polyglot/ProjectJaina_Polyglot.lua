-- ==============================================================================
-- PROJECT JAINA: POLYGLOT (CLIENT ADDON FOR WOW 3.3.5a)
-- ==============================================================================
-- AddOn cliente para gestión visual e interactiva de traducciones en tiempo real.
-- Permite visualizar el texto original en tooltips, alternar canales y cambiar idioma.
--
-- Autor: DarckRovert & Antigravity (Claude Mythos 5)
-- Versión: 1.0.0
-- ==============================================================================

local ADDON_NAME = "ProjectJaina_Polyglot"
local PREFIX = "PJ_POLYGLOT"

-- Configuración por defecto
local defaults = {
    enabled = true,
    showTooltips = true,
    showTags = true,
    preferredLocale = GetLocale() or "esES",
    channels = {
        whisper = true,
        party = true,
        raid = true,
        guild = true,
        world = true,
    }
}

ProjectJaina_PolyglotDB = ProjectJaina_PolyglotDB or defaults

local originalCache = {} -- Hash/Clave -> Texto Original

-- ==============================================================================
-- 1. REGISTRO Y GESTIÓN DE HIPERENLACES INTERACTIVOS (|Hpolyglot:...|h)
-- ==============================================================================
local origSetItemRef = SetItemRef
SetItemRef = function(link, text, button, chatFrame)
    if link:sub(1, 9) == "polyglot:" then
        local key = link:sub(10)
        local orig = originalCache[key]
        if orig and GameTooltip then
            GameTooltip:SetOwner(UIParent, "ANCHOR_CURSOR")
            GameTooltip:ClearLines()
            GameTooltip:AddLine("|cff00ccffProject Jaina Polyglot|r", 1, 1, 1)
            GameTooltip:AddLine("Texto Original en idioma del emisor:", 0.8, 0.8, 0.8)
            GameTooltip:AddLine(orig, 1, 1, 0, true)
            GameTooltip:AddLine("|cff808080Haz clic para copiar o cerrar.|r", 0.5, 0.5, 0.5)
            GameTooltip:Show()
        end
        return
    end
    return origSetItemRef(link, text, button, chatFrame)
end

-- ==============================================================================
-- 2. FILTRADO Y ENRIQUECIMIENTO DE MENSAJES DE CHAT
-- ==============================================================================
local function PolyglotChatFilter(self, event, msg, author, ...)
    if not ProjectJaina_PolyglotDB.enabled or not msg then
        return false, msg, author, ...
    end

    -- Detectar etiquetas de traducción enviadas por el servidor: [SRC->TGT]
    local srcTag, tgtTag, content = msg:match("|cff00ccff%[([%a%-]+)%->([%a%-]+)%]|r%s*(.*)")
    if srcTag and tgtTag and content then
        local cacheKey = tostring(#originalCache + 1)
        originalCache[cacheKey] = content

        local formattedTag = ""
        if ProjectJaina_PolyglotDB.showTags then
            -- Enlace interactivo en la etiqueta para desplegar tooltip con un clic
            formattedTag = string.format("|Hpolyglot:%s|h|cff00ccff[%s->%s]|h|r ", cacheKey, srcTag, tgtTag)
        end

        local finalMsg = formattedTag .. content
        return false, finalMsg, author, ...
    end

    return false, msg, author, ...
end

-- Registrar filtros de eventos en los marcos de chat
local chatEvents = {
    "CHAT_MSG_SAY",
    "CHAT_MSG_YELL",
    "CHAT_MSG_WHISPER",
    "CHAT_MSG_WHISPER_INFORM",
    "CHAT_MSG_PARTY",
    "CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID",
    "CHAT_MSG_RAID_LEADER",
    "CHAT_MSG_GUILD",
    "CHAT_MSG_CHANNEL",
}

for _, evt in ipairs(chatEvents) do
    ChatFrame_AddMessageEventFilter(evt, PolyglotChatFilter)
end

-- ==============================================================================
-- 3. RECEPTOR DE ADDON MESSAGES DEL SERVIDOR (PJ_POLYGLOT)
-- ==============================================================================
local frame = CreateFrame("Frame", "ProjectJaina_PolyglotFrame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("CHAT_MSG_ADDON")

frame:SetScript("OnEvent", function(self, event, prefix, msg, channel, sender)
    if event == "ADDON_LOADED" and prefix == ADDON_NAME then
        if not ProjectJaina_PolyglotDB then
            ProjectJaina_PolyglotDB = defaults
        end
        print("|cff00ccff[Project Jaina Polyglot]|r v1.0.0 cargado. Usa |cffffff00/polyglot|r o |cffffff00.translate|r.")
    elseif event == "CHAT_MSG_ADDON" and prefix == PREFIX then
        -- Guardar metadatos extendidos recibidos del servidor
        local kind, src, tgt, original = strsplit("\t", msg)
        if kind and original then
            local cacheKey = tostring(#originalCache + 1)
            originalCache[cacheKey] = original
        end
    end
end)

-- ==============================================================================
-- 4. BOTÓN FLOTANTE DISCRETO EN EL CHAT (WIDGET 🌐)
-- ==============================================================================
local function CreateChatToggleButton()
    local btn = CreateFrame("Button", "PolyglotChatToggleBtn", ChatFrame1)
    btn:SetWidth(18)
    btn:SetHeight(18)
    btn:SetPoint("TOPRIGHT", ChatFrame1, "TOPRIGHT", -4, -4)
    btn:SetNormalTexture("Interface\\Icons\\Spell_Arcane_PortalDalaran")
    btn:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight")
    btn:GetNormalTexture():SetTexCoord(0.08, 0.92, 0.08, 0.92)

    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("|cff00ccffProject Jaina Polyglot|r", 1, 1, 1)
        local status = ProjectJaina_PolyglotDB.enabled and "|cff00ff00Activado|r" or "|cffff0000Desactivado|r"
        GameTooltip:AddLine("Traductor Universal: " .. status, 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Clic: Alternar /polyglot menu", 1, 1, 0)
        GameTooltip:Show()
    end)

    btn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)

    btn:SetScript("OnClick", function(self)
        ProjectJaina_PolyglotDB.enabled = not ProjectJaina_PolyglotDB.enabled
        local state = ProjectJaina_PolyglotDB.enabled and "|cff00ff00activada|r" or "|cffff0000desactivada|r"
        print("|cff00ccff[Project Jaina Polyglot]|r Traducción " .. state .. ".")
    end)
end

-- Intentar crear el botón tras cargar la interfaz
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
initFrame:SetScript("OnEvent", function()
    CreateChatToggleButton()
    initFrame:UnregisterAllEvents()
end)

-- ==============================================================================
-- 5. COMANDO SLASH (/polyglot y /tr)
-- ==============================================================================
SLASH_POLYGLOT1 = "/polyglot"
SLASH_POLYGLOT2 = "/pjtr"
SlashCmdList["POLYGLOT"] = function(msg)
    local cmd, arg = msg:match("^(%S+)%s*(.*)$")
    cmd = cmd and cmd:lower() or "toggle"

    if cmd == "toggle" then
        ProjectJaina_PolyglotDB.enabled = not ProjectJaina_PolyglotDB.enabled
        local state = ProjectJaina_PolyglotDB.enabled and "|cff00ff00ACTIVADA|r" or "|cffff0000DESACTIVADA|r"
        print("|cff00ccff[Project Jaina Polyglot]|r Traducción " .. state .. ".")
    elseif cmd == "tags" then
        ProjectJaina_PolyglotDB.showTags = not ProjectJaina_PolyglotDB.showTags
        local state = ProjectJaina_PolyglotDB.showTags and "|cff00ff00visibles|r" or "|cffff0000ocultas|r"
        print("|cff00ccff[Project Jaina Polyglot]|r Etiquetas [SRC->TGT] " .. state .. ".")
    else
        print("|cff00ccff=== Project Jaina Polyglot ===|r")
        print("  |cffffff00/polyglot toggle|r - Activa o desactiva la traducción visual.")
        print("  |cffffff00/polyglot tags|r - Muestra u oculta las etiquetas [SRC->TGT].")
        print("  |cffffff00.translate <on|off|lang|status>|r - Control del servidor.")
    end
end
