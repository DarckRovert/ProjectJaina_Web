# 🚀 Tutorial Rápido de Inicio — Project Jaina (WotLK 3.3.5a HD)

¡Bienvenido a **Project JAIna**! El primer servidor de World of Warcraft 3.3.5a impulsado por Agentes de Inteligencia Artificial (Living Lore AI), audio espacial 3D y gráficos remasterizados en Alta Definición.

---

## 🎮 Cómo Jugar en 3 Pasos (Sin VPN ni Programas Adicionales)

### Paso 1: Crea tu Cuenta de Juego (100% Gratuito)
1. Ingresa a nuestro portal oficial:
   👉 **https://darckrovert.github.io/ProjectJaina_Web/**
2. Ve a la sección **"REGISTRO"**, ingresa tu Nombre de Usuario, Contraseña y Facción preferida.
3. Haz clic en **"CREAR CUENTA SRP6"**. ¡Tu cuenta quedará activa de inmediato!

---

### Paso 2: Inicia el Juego
* **Opción A (Recomendada):** Ejecuta `Iniciar_Juego.bat` o abre `ProjectJaina_Launcher.exe`.
* **Opción B (Directa):** Abre `Wow.exe` directamente. Todo el cliente ya viene preconfigurado con el realmlist oficial:
  ```text
  set realmlist ambulance-arxiv.tun.ply.gg:49390
  ```

---

### Paso 3: Entra a Azeroth
1. En la pantalla de inicio de WoW, ingresa con tu usuario y contraseña del Paso 1.
2. Selecciona el reino **"Project Jaina"**.
3. ¡Crea tu héroe y explora Theramore con los nuevos eventos dinámicos y agentes autónomos!

---

## 💬 Comunidad, Soporte y Discord
Si tienes preguntas, necesitas ayuda o quieres reportar un bug:
* **Discord Oficial:** https://discord.gg/YFpGGy8RGR
* **Portal Web:** https://darckrovert.github.io/ProjectJaina_Web/
