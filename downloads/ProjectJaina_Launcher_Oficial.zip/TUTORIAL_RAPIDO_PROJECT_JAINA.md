# Project Jaina — Guía Rápida & Tutorial Oficial (WotLK 3.3.5a HD)

> **Manual de Operación Visual (Zero-Code):** Diseñado especialmente para amigos, colegas y jugadores de la hermandad. Todo se opera mediante interfaz gráfica en 1 solo clic.

---

## 👑 Quiénes Somos (Project Jaina)

* **👑 DarckRovert (Elnazzareno):** Fundador, Director General & Arquitecto de Software.
* **⚡ FranFranco (Frank / Cheki):** Co-fundador & Operador del Nodo de Cómputo (32 Cores).
* **🧠 Antigravity L9 (Mythos 5):** Staff Engineer de Inteligencia Artificial & Ingeniería de Núcleo.
* **💬 Discord Oficial de la Comunidad:** [https://discord.gg/YFpGGy8RGR](https://discord.gg/YFpGGy8RGR)

*Project Jaina es un ecosistema soberano desarrollado de forma independiente por el equipo de ingeniería de Project Jaina, en colaboración técnica y hermandad con la comunidad de World of Warcraft Perú.*

---

## 🎮 Tutorial 1: Cómo Entrar a Jugar en 3 Minutos (Modo Jugador)

No necesitas instalar programas complejos ni escribir comandos. Sigue estos 3 pasos:

### Paso 1: Encender Radmin VPN
1. Abre **Radmin VPN** en tu computadora.
2. Haz clic en el botón de encendido (debe mostrar el círculo en verde).
3. Ve a **Red -> Unirse a una red existente**:
   * **Nombre de Red:** `Project_Jaina`
   * **Contraseña:** `thedarck1993`
4. ¡Listo! Ya estás conectado al clúster de tus amigos.

### Paso 2: Abrir el Hub Oficial
1. Abre el acceso directo **Project Jaina** (o ejecuta `Iniciar_ProjectJaina_Hub.bat`).
2. En la pestaña **"⚔️ Modo Jugador"**:
   * Comprueba que esté seleccionado **"Red Radmin VPN (Project Jaina)"**.
   * El indicador superior confirmará en color verde: `🟢 Clúster Radmin ONLINE (26.140.157.205)`.

### Paso 3: Clic en Jugar
1. Haz clic en el botón gigante: **⚔️ INICIAR JUEGO (WOW 3.3.5a)**.
2. El Hub configurará automáticamente tu conexión y abrirá el juego.
3. Si no tienes cuenta aún, pulsa el botón **"🌐 Registro de Cuentas SRP6"** en el Hub para crear tu usuario y contraseña al instante.

---

## ⚡ Tutorial 2: Manual del Colega de Clúster (FranFranco / Hosts Secundarios)

Para operar el servidor, simular los bots o activar el audio 3D, **ya no necesitas abrir 6 consolas negras**. Todo se controla desde el Hub:

```
┌────────────────────────────────────────────────────────┐
│         PROJECT JAINA MASTER HUB — NODO CLÚSTER        │
├────────────────────────────────────────────────────────┤
│  🟢 MySQL 8.4 [3306]       🟢 AuthServer [3724]        │
│  🟢 WorldServer [8085]     🟢 Voz 3D WebRTC [3050]     │
│  🟢 Chatter IA [5005]      🟢 Sentinel [8089]          │
├────────────────────────────────────────────────────────┤
│  [▶️ Iniciar Todo el Clúster]   [⏹️ Detener Servicios]   │
│  [⚡ Recargar Scripts (SOAP)]   [📊 Consola Web GM]     │
└────────────────────────────────────────────────────────┘
```

### Cómo Iniciar el Servidor:
1. Abre **Project Jaina Master Hub**.
2. Cambia a la pestaña **"⚡ Nodo Clúster (Servidor)"**.
3. Haz clic en **▶️ Iniciar Todo el Clúster**:
   * El Hub iniciará los servicios en orden seguro en segundo plano.
   * Verás cómo los círculos de telemetría pasan de rojo a **verde (ONLINE)**.
4. El visor de eventos inferior te mostrará exactamente qué está ocurriendo sin ventanas invasivas.

### Cómo Recargar Scripts en Caliente (Sin Reiniciar):
* Si Darck o el equipo actualizaron algún archivo de Lua o modo de juego, pulsa el botón **⚡ Recargar Scripts (SOAP)**.
* El servidor recargará la lógica en milisegundos sin desconectar a los jugadores.

### Cómo Apagar el Servidor:
* Pulsa **⏹️ Detener Servicios**. El Hub cerrará los procesos limpiamente protegiendo las bases de datos de corrupción.

---

## 🧙‍♀️ Tutorial 3: Lady Jaina y el Mundo Vivo

Lady Jaina Valiente está integrada en el reino con doble manifestación viva:

### 1. La Jaina de Theramore (PNJ de Mundo - Nivel 80)
* Se encuentra en el Bastión de Theramore (Kalimdor).
* **Menú de Diálogo (Gossip):** Habla con ella para pedir su bendición arcana, consultarle sobre la guerra en Rasganorte, sobre Arthas en Stratholme o sobre el tratado de paz con Thrall.
* **Charla en `/say`:** Acércate a ella y háblale en el chat blanco:
  * *"Lady Jaina, ¿aún crees en la paz?"*
  * *"Dame tu bendición"*
  * Jaina te escuchará, se girará hacia ti y te responderá con voz y animaciones arcanas.

### 2. Jaina como HeroBot de Combate (Compañera de Mazmorra)
* Puedes invocarla en tu grupo usando el comando:
  ```text
  .playerbots bot add Jaina
  ```
* **Sistema de Afinidad:**
  * Si tu afinidad es baja (< 15), Jaina te susurrará educadamente que aún debes ganarte su confianza en Theramore.
  * Si cumples misiones y colaboras con ella, tu afinidad aumentará (+2 a +5).
  * A partir de 15 puntos, marchará contigo bendiciendo a tu grupo con *Brillantez Arcana*.
  * A 50 puntos (Rango Heroico), luchará como tu hermana de armas con vestiduras épicas y *Archus, Gran Báculo de Antonidas*.

---

## 🧩 Tutorial 4: La Suite de los 18 AddOns Oficiales (HD & Calidad de Vida)

El cliente ya incluye preinstalada la suite canónica de **18 AddOns oficiales** en la carpeta `Interface\AddOns`. No requieres descargas adicionales ni configuradores externos:

### 1. Interfaz Visual & Gráficos Modernos
* **`ProjectJaina_DragonflightUI` (`cDF`):** Transforma la interfaz clásica a la estética estilizada de *Dragonflight* (micro-menú estilizado, barras de acción dinámicas y unitframes limpios).
* **`ProjectJaina_AbbreviatedStatus`:** Números limpios y compactos (ej. `12.4k`, `1.2M`) en vida y maná.
* **`ProjectJaina_Graphics`:** Panel de opciones avanzadas y presets anti-crash de 32-bit (`farclip 800`).
* **`ProjectJaina_Talented`:** Árbol de talentos expandido con visualización completa de todas las ramas.

### 2. Inmersión, Lore & Sistemas de Comunidad
* **`ProjectJaina_BattlePass`:** Pase de batalla estacional (Free y VIP) con misiones diarias y cosméticos.
* **`ProjectJaina_Companion`:** Hub social de grupo con telemetría de addons y badges de hermandad.
* **`Chatter_Companion`:** Gestor de bots con IA neuronal, integración con LM Studio y diálogo táctico (`/bots` o `/chatter`).
* **`ProjectJaina_GameModes`:** Selector visual al crear personajes para retos Hardcore (permadeath) o Ironman.
* **`ProjectJaina_LoreHUD`:** Subtítulos cinemáticos en vivo cuando interactúas con Jaina y líderes del mundo.
* **`ProjectJaina_MultiBot`:** Mando táctico visual para controlar y dar órdenes a tus bots acompañantes.
* **`ProjectJaina_PrideTrace`:** Indicador narrativo de resonancia arcana y orgullo de Theramore.
* **`ProjectJaina_RaidSuite`:** Alertas tácticas de encuentros y jefes de mazmorra.
* **`ProjectJaina_VisualShop`:** Tienda cosmética integrada en el juego.
* **`ProjectJaina_Voice`:** Indicador y telemetría de voz espacial 3D en proximidad (`/voz`).
* **`ProjectJaina_Wardrobe`:** Armario de transfiguración y personalización de apariencias.

### 3. Herramientas Maestras de Moderación (Solo Clientes GM)
* **`ProjectJaina_AdminTools`:** Panel administrativo en 1 clic para gestión de eventos y servidor.
* **`ProjectJaina_GMGenie`:** Suite de asistencia rápida a jugadores y tickets de moderación.
* **`ProjectJaina_IntiObjGPS`:** Georreferenciación y telemetría de coordenadas en staging.
* **`ProjectJaina_TBCBalance`:** Telemetría de calibración de balance y combate.

---

## 💡 Comandos Rápidos de Utilidad en el Juego

| Comando | Acción |
| :--- | :--- |
| `/jaina` o `/lore` | Abre el panel de estado de Lore y afinidad con Lady Jaina. |
| `/voz` | Genera un PIN efímero para conectar tu micrófono en la web de Voz Espacial 3D. |
| `/bots` o `/chatter` | Abre el Gestor de Bots con Inteligencia Artificial (Chatter LLM). |
| `.playerbots bot add Jaina` | Invoca a Lady Jaina a tu grupo de combate (requiere nivel y afinidad). |
| `.playerbots bot remove Jaina` | Despide a Jaina del grupo de forma segura. |
| `/pass` | Abre la ventana del Pase de Batalla estacional de Project Jaina. |
| `/cameradistancemaxfactor 4` | Aleja la cámara al máximo permitido para raids y combate panorámico. |
| `/rl` | Recarga la interfaz de usuario en 1 segundo sin salir del juego. |

---

## 🛡️ Tutorial 5: Operaciones en Vivo, Resiliencia y Emergencias (Guía Staff L9)

Para mantener 100% de disponibilidad sin tirar el reino ni perder datos de jugadores, utiliza las siguientes herramientas desde la **Consola Web GM** (`http://127.0.0.1:8088`):

### 1. Parches de Código en Caliente (Zero Downtime)
* **Modificaciones en Scripts Lua / Eluna:** Edita el archivo en `server/lua_scripts/` y pulsa `[⚡ Hot-Reload Lua (.reload ale)]` en la barra superior. Entra en vigor en <100ms sin tirar a nadie.
* **Modificaciones en Tablas de Mundo (Quests, Daño, Spawns):** Pulsa `[🔄 Recargar Tablas BD]` para refrescar los templates en memoria RAM.

### 2. Protección Anti-Rollback & Snapshots de Emergencia
* **Autosave Permanente:** Los personajes se guardan automáticamente cada **2 minutos** y al instante tras cada avance de misión, logro o loot de rareza superior.
* **Mantenimiento Programado:** Antes de reiniciar o apagar, pulsa `[💾 Guardar Todo (.saveall)]`.
* **Snapshots Atómicos:** Pulsa `[📦 Snapshot BD]` para generar una copia comprimida consistente `.sql.gz` de `acore_characters` y `acore_auth` en `backups/db_snapshots/` en menos de 3 segundos sin bloquear escrituras de jugadores.

### 3. Conmutación de Emergencia (Sentinel Failover a FranFranco)
* Si el Master físico sufre un fallo de hardware o corte eléctrico prolongado:
  1. En la pestaña **"🌐 Clúster Mesh"**, pulsa `[🚨 Promover España a World Master (Failover Inmediato)]`.
  2. La autoridad del reino, túneles y base de datos conmutan automáticamente a la estación de 32 Cores de FranFranco (`26.202.12.241`).
  3. Al restablecer el Master principal, pulsa `[🔄 Restaurar Perú a World Master (Node 1)]`.

### 4. Blindaje contra Colisión de Código Concurrente
* Si ambos desarrolladores editan el mismo archivo simultáneamente, el sincronizador SSOT y Sentinel detectan automáticamente el desfasaje temporal y generan un respaldo protegido `<archivo>_conflict_<timestamp>` antes de aplicar los cambios, garantizando **cero destrucción de código**.
