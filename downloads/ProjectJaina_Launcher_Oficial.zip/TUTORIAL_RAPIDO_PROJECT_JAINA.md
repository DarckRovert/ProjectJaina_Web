# 🚀 Tutorial Rápido de Inicio — Project Jaina (WotLK 3.3.5a HD)

¡Bienvenido a **Project JAIna**! El primer servidor de World of Warcraft 3.3.5a impulsado por Agentes de Inteligencia Artificial (Living Lore AI), audio espacial 3D y gráficos remasterizados en Alta Definición.

---

## 🎮 Cómo Jugar en 3 Pasos (Sin VPN ni Programas Adicionales)

### Paso 1: Crea tu Cuenta de Juego (100% Gratuito)
1. Ingresa a nuestro portal oficial:
   👉 **https://darckrovert.github.io/ProjectJaina_Web/**
2. Ve a la sección **"REGISTRO"**, ingresa tu Nombre de Usuario, Contraseña y Facción preferida (**Alianza**, **Horda** o **Kirin Tor de Dalaran**).
3. Haz clic en **"CREAR CUENTA SRP6"**. ¡Tu cuenta quedará activa de inmediato!

---

### Paso 2: Inicia el Juego
* **Opción A (Recomendada):** Ejecuta `Iniciar_Juego_Oficial.bat` o abre `ProjectJaina_Launcher.exe`. El lanzador levanta el túnel loopback transparente e inicia el juego.
* **Opción B (Directa):** Abre `Wow.exe` directamente. Todo el cliente viene preconfigurado de fábrica con:
  ```text
  set realmlist 127.0.0.1
  ```
  *(Nota: Ejecuta al menos una vez `Iniciar_Juego_Oficial.bat` o el Lanzador para asegurar que el proxy loopback L4 esté activo en segundo plano).*

---

### Paso 3: Entra a Azeroth
1. En la pantalla de inicio de WoW, ingresa con tu usuario y contraseña del Paso 1.
2. Selecciona el reino deseado (**"Project Jaina"** o **"WanitosGym"**).
3. ¡Crea tu héroe y explora Theramore con los nuevos eventos dinámicos y agentes autónomos!

---

## 💬 Comunidad, Soporte y Discord
Si tienes preguntas, necesitas ayuda o quieres reportar un bug:
* **Discord Oficial:** https://discord.gg/769jdzAYP
* **Portal Web:** https://darckrovert.github.io/ProjectJaina_Web/
