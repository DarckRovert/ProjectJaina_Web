@echo off
title Project Jaina - Launcher Oficial del Jugador
if exist ProjectJaina_Launcher.exe (
    start "" ProjectJaina_Launcher.exe
    exit /b 0
)
echo [AVISO] Ejecuta ProjectJaina_Launcher.exe directamente haciendo doble clic.
pause
