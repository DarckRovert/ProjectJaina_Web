@echo off
title Project Jaina - Iniciar Juego (Lanzador Oficial)
cd /d "%~dp0"
if exist ProjectJaina_Launcher.exe (
    start "" ProjectJaina_Launcher.exe
    exit /b 0
)
echo [AVISO] Ejecuta ProjectJaina_Launcher.exe directamente haciendo doble clic.
pause
